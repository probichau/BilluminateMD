# BilluminateMD - Production Deployment Reference

## Production URLs

- **Frontend Application**: https://app.billuminate.com
- **Backend API**: https://api.billuminate.com
- **Health Check**: https://api.billuminate.com/health

## AWS Resources

### Elastic Beanstalk (Backend)
- **Environment Name**: billuminatemd-prod
- **Application Name**: billuminatemd
- **Platform**: Node.js 20 on Amazon Linux 2023
- **Region**: us-east-1
- **CNAME**: billuminatemd-prod.eba-5yuhzdit.us-east-1.elasticbeanstalk.com
- **Status**: Ready ✅
- **Health**: Green ✅

### AWS Amplify (Frontend)
- **App ID**: d83mc8ny8u2m7
- **Domain**: app.billuminate.com
- **SSL**: Amplify Managed Certificate
- **Auto-Deploy**: Enabled (main branch)

### Route 53 (DNS)
- **Domain**: billuminate.com
- **API Subdomain**: api.billuminate.com (CNAME to EB)
- **App Subdomain**: app.billuminate.com (Amplify managed)

### SSL/TLS Certificates
- **Certificate**: *.billuminate.com (wildcard)
- **Status**: Issued
- **Service**: AWS Certificate Manager (ACM)
- **Validates**: api.billuminate.com, app.billuminate.com

## Deployment Commands

### Backend Deployment
```bash
cd backend
eb deploy
```

### Frontend Deployment
```bash
cd frontend
git add .
git commit -m "Your commit message"
git push origin main
# Amplify auto-deploys
```

## Environment Variables

### Backend (Elastic Beanstalk)
Set via AWS Console or `eb setenv`:
- NODE_ENV=production
- PORT=8080
- DATABASE_URL
- JWT_SECRET
- STRIPE_SECRET_KEY
- AWS_ACCESS_KEY_ID
- AWS_SECRET_ACCESS_KEY
- AWS_S3_BUCKET
- AWS_REGION
- FRONTEND_URL=https://app.billuminate.com
- GOOGLE_CLIENT_ID (pending)
- GOOGLE_CLIENT_SECRET (pending)
- GOOGLE_CALLBACK_URL (pending)

### Frontend (Amplify)
Set via Amplify Console:
- VITE_API_URL=https://api.billuminate.com
- VITE_STRIPE_PUBLIC_KEY

## Current Status (2026-01-19)

✅ Backend deployed and healthy
✅ Frontend deployed and accessible
✅ HTTPS enabled on both domains
✅ CORS configured for custom domain
✅ DNS records active
✅ SSL certificates valid

## Pending Configuration

### Google OAuth Setup
1. Create Google Cloud Console project
2. Configure OAuth consent screen
3. Create OAuth 2.0 credentials
4. Add to backend environment variables:
   - GOOGLE_CLIENT_ID
   - GOOGLE_CLIENT_SECRET
   - GOOGLE_CALLBACK_URL=https://api.billuminate.com/api/auth/google/callback

### Stripe Production
1. Switch from test keys to live keys in both:
   - Backend: STRIPE_SECRET_KEY
   - Frontend: VITE_STRIPE_PUBLIC_KEY
2. Configure webhooks for production URL

### HIPAA Compliance
1. Sign AWS Business Associate Agreement (BAA)
2. Enable RDS encryption at rest
3. Enable S3 bucket encryption
4. Configure CloudTrail logging
5. Implement audit logging

## Monitoring

### Health Checks
- **Backend**: GET https://api.billuminate.com/health
- **Expected Response**: `{"status":"ok","message":"BilluminateMD API is running"}`

### AWS Console Access
- **Elastic Beanstalk**: Console → Elastic Beanstalk → billuminatemd-prod
- **Amplify**: Console → Amplify → billuminatemd
- **Route 53**: Console → Route 53 → billuminate.com

## Troubleshooting

### Check Backend Logs
```bash
eb logs
```

### Check Backend Status
```bash
eb status
```

### Check Frontend Build Logs
Visit Amplify Console → App → Deployments

### Force Frontend Rebuild
```bash
git commit --allow-empty -m "Trigger rebuild"
git push origin main
```

## Security Notes

- All traffic encrypted with HTTPS
- CORS restricted to app.billuminate.com
- JWT tokens for authentication
- Stripe handles payment data (PCI compliant)
- Healthcare data requires HIPAA compliance measures

## Support Resources

- **AWS Documentation**: https://docs.aws.amazon.com/
- **Elastic Beanstalk CLI**: https://docs.aws.amazon.com/elasticbeanstalk/latest/dg/eb-cli3.html
- **Amplify Hosting**: https://docs.amplify.aws/
