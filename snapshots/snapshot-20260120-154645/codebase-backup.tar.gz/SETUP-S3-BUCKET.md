# S3 Bucket Setup Instructions

## Step 1: Create S3 Bucket

1. Go to **AWS S3 Console**: https://s3.console.aws.amazon.com/s3/
2. Click **Create bucket**
3. Configure:
   - **Bucket name**: `billuminatemd-uploads`
   - **AWS Region**: `US East (N. Virginia) us-east-1`
   - **Block Public Access settings**: Keep all 4 boxes checked (Block all public access) ✅
   - **Bucket Versioning**: Enable
   - **Default encryption**: Enable (SSE-S3)
4. Click **Create bucket**

## Step 2: Configure CORS (Important for file uploads)

1. Click on your newly created bucket `billuminatemd-uploads`
2. Go to **Permissions** tab
3. Scroll to **Cross-origin resource sharing (CORS)**
4. Click **Edit**
5. Paste this configuration:

```json
[
  {
    "AllowedHeaders": [
      "*"
    ],
    "AllowedMethods": [
      "GET",
      "PUT",
      "POST",
      "DELETE",
      "HEAD"
    ],
    "AllowedOrigins": [
      "https://app.billuminate.com",
      "http://localhost:5173"
    ],
    "ExposeHeaders": [
      "ETag"
    ],
    "MaxAgeSeconds": 3000
  }
]
```

6. Click **Save changes**

## Step 3: Get Your AWS Credentials

You need an AWS Access Key with S3 permissions:

### Option A: Use Existing IAM User
1. Go to **IAM Console**: https://console.aws.amazon.com/iam/
2. Click **Users** → Select your user
3. Go to **Security credentials** tab
4. Click **Create access key**
5. Select **Application running outside AWS**
6. Save both:
   - Access key ID
   - Secret access key (shown only once!)

### Option B: Create New IAM User for BilluminateMD
1. Go to **IAM Console** → **Users** → **Create user**
2. Username: `billuminatemd-s3-user`
3. Attach policy: **AmazonS3FullAccess** (or create custom policy for just your bucket)
4. Create access key as in Option A

## Step 4: Get Other API Keys

### Anthropic Claude API Key
1. Go to: https://console.anthropic.com/
2. Sign in or create account
3. Go to **API Keys** → **Create Key**
4. Copy the key (starts with `sk-ant-`)

### Stripe Keys
1. Go to: https://dashboard.stripe.com/
2. Sign in to your account
3. Click **Developers** → **API keys**
4. Copy:
   - **Secret key** (starts with `sk_test_` or `sk_live_`)
5. For webhook secret:
   - Go to **Developers** → **Webhooks** → **Add endpoint**
   - Endpoint URL: `https://api.billuminate.com/api/payment/webhook`
   - Select events: `checkout.session.completed`, `payment_intent.succeeded`
   - Click **Add endpoint**
   - Click **Reveal** next to **Signing secret** (starts with `whsec_`)

## Step 5: Configure Environment Variables

1. Open the file: `backend/setup-production-env.sh`
2. Replace all placeholder values:
   ```bash
   AWS_ACCESS_KEY_ID="YOUR_AWS_ACCESS_KEY_HERE"      # From Step 3
   AWS_SECRET_ACCESS_KEY="YOUR_AWS_SECRET_KEY_HERE"  # From Step 3
   ANTHROPIC_API_KEY="YOUR_ANTHROPIC_API_KEY_HERE"   # From Step 4
   STRIPE_SECRET_KEY="YOUR_STRIPE_SECRET_KEY_HERE"   # From Step 4
   STRIPE_WEBHOOK_SECRET="YOUR_STRIPE_WEBHOOK_SECRET_HERE"  # From Step 4
   ```
3. Save the file
4. Run from terminal:
   ```bash
   cd backend
   bash setup-production-env.sh
   ```

## Step 6: Verify

After running the script, verify environment variables are set:

```bash
cd backend
/Users/bernardpeterrobichau/Library/Python/3.13/bin/eb printenv
```

You should see all the variables listed.

## Step 7: Test

1. Wait 2-3 minutes for environment to restart
2. Go to: https://app.billuminate.com
3. Upload a test PDF file
4. Should see processing without errors!

## Troubleshooting

### If upload still fails:
1. Check S3 bucket CORS is configured correctly
2. Verify IAM user has S3 permissions
3. Check backend logs: `cd backend && eb logs`
4. Test S3 access from backend: `curl https://api.billuminate.com/health`

### Common Issues:
- **Access Denied**: IAM user needs S3 permissions
- **CORS Error**: Check CORS configuration in S3 bucket
- **Invalid Credentials**: Double-check access key and secret key
- **Bucket Not Found**: Verify bucket name is exactly `billuminatemd-uploads`
