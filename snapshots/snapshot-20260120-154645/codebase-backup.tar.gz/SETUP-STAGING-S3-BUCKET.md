# Staging S3 Bucket Setup

## Next Steps for Staging Environment

### Step 1: Create Staging S3 Bucket

1. Go to **AWS S3 Console**: https://s3.console.aws.amazon.com/s3/
2. Click **Create bucket**
3. Configure:
   - **Bucket name**: `billuminatemd-staging-uploads`
   - **AWS Region**: `US East (N. Virginia) us-east-1`
   - **Block Public Access settings**: Keep all 4 boxes checked (Block all public access) ✅
   - **Bucket Versioning**: Enable
   - **Default encryption**: Enable (SSE-S3)
4. Click **Create bucket**

### Step 2: Configure CORS

1. Click on your bucket `billuminatemd-staging-uploads`
2. Go to **Permissions** tab
3. Scroll to **Cross-origin resource sharing (CORS)**
4. Click **Edit**
5. Paste this configuration:

```json
[
  {
    "AllowedHeaders": [
      "*"
    ],
    "AllowedMethods": [
      "GET",
      "PUT",
      "POST",
      "DELETE",
      "HEAD"
    ],
    "AllowedOrigins": [
      "https://staging.billuminate.com",
      "http://localhost:5173"
    ],
    "ExposeHeaders": [
      "ETag"
    ],
    "MaxAgeSeconds": 3000
  }
]
```

6. Click **Save changes**

### Step 3: Configure Staging Environment Variables

You'll need to set these environment variables in Elastic Beanstalk for staging:

```bash
# AWS S3 (use same credentials as production)
AWS_ACCESS_KEY_ID="<your-aws-access-key-id>"
AWS_SECRET_ACCESS_KEY="<your-aws-secret-access-key>"
AWS_BUCKET_NAME="billuminatemd-staging-uploads"
AWS_REGION="us-east-1"

# Database (already set up)
DATABASE_URL="postgresql://postgres.bgliypuasymcpvydqmur:F1zxWuM9rKQ8CaQc@aws-1-us-east-1.pooler.supabase.com:5432/postgres"

# API Keys (use test keys for staging)
ANTHROPIC_API_KEY="<your-anthropic-api-key>"
STRIPE_SECRET_KEY="<your-stripe-test-key>"  # Use test key: sk_test_...
STRIPE_WEBHOOK_SECRET="<your-stripe-test-webhook-secret>"

# Environment
NODE_ENV="staging"
```

### Step 4: Set Environment Variables in Elastic Beanstalk

**Option A: AWS Console**
1. Go to Elastic Beanstalk Console: https://console.aws.amazon.com/elasticbeanstalk/
2. Select application: `BilluminateMD`
3. Select environment: `BilluminateMD-staging-env`
4. Go to **Configuration** → **Software** → **Edit**
5. Add all environment variables from Step 3
6. Click **Apply**

**Option B: AWS CLI** (faster)
```bash
cd backend
eb use BilluminateMD-staging-env

# Set variables one by one
eb setenv \
  AWS_ACCESS_KEY_ID="<your-key>" \
  AWS_SECRET_ACCESS_KEY="<your-secret>" \
  AWS_BUCKET_NAME="billuminatemd-staging-uploads" \
  AWS_REGION="us-east-1" \
  DATABASE_URL="postgresql://postgres.bgliypuasymcpvydqmur:F1zxWuM9rKQ8CaQc@aws-1-us-east-1.pooler.supabase.com:5432/postgres" \
  ANTHROPIC_API_KEY="<your-key>" \
  STRIPE_SECRET_KEY="<your-test-key>" \
  STRIPE_WEBHOOK_SECRET="<your-test-webhook>" \
  NODE_ENV="staging"
```

### Step 5: Deploy Backend to Staging

```bash
cd backend
git checkout staging
eb use BilluminateMD-staging-env
eb deploy
```

### Step 6: Verify Deployment

1. Check environment status:
   ```bash
   eb status
   ```

2. View logs if needed:
   ```bash
   eb logs
   ```

3. Test the API:
   ```bash
   curl https://<staging-url>.elasticbeanstalk.com/health
   ```

### Step 7: Update Frontend with Staging API URL

1. Get your staging backend URL:
   ```bash
   cd backend
   eb status | grep CNAME
   ```

2. Update frontend environment variable in AWS Amplify:
   - Go to AWS Amplify Console
   - Select your staging app
   - Go to **Environment variables**
   - Set `VITE_API_URL` to your staging backend URL
   - Redeploy frontend

### Step 8: Configure staging.billuminate.com Domain

**Backend (Elastic Beanstalk):**
1. Go to Route 53
2. Select hosted zone: `billuminate.com`
3. Create CNAME record:
   - Name: `staging-api`
   - Type: CNAME
   - Value: `<your-eb-url>.elasticbeanstalk.com`

**Frontend (Amplify):**
1. In Amplify Console, go to **Domain management**
2. Add domain: `staging.billuminate.com`
3. Follow DNS configuration steps

### Step 9: Test End-to-End

1. Visit `https://staging.billuminate.com`
2. Sign up / Sign in
3. Upload a test PDF
4. Verify file appears in S3 bucket `billuminatemd-staging-uploads`
5. Check that audit analysis works
6. Test payment flow with Stripe test cards

## Summary

After completing these steps, you'll have:
- ✅ Staging S3 bucket for file uploads
- ✅ Staging database with all tables
- ✅ Backend deployed to staging environment
- ✅ Frontend connected to staging backend
- ✅ Custom domain configured
- ✅ Full staging environment ready for testing

## Notes

- **Use Stripe test keys** for staging (sk_test_...)
- **S3 bucket name must be globally unique** - if taken, use `billuminatemd-staging-uploads-2`
- **IAM user credentials** - reuse the same AWS credentials from production
- **Cost** - Staging S3 will cost ~$1-5/month with light usage
