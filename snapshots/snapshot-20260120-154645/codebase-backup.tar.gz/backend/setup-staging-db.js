import pg from 'pg'
const { Client } = pg

const STAGING_DATABASE_URL = 'postgresql://postgres.bgliypuasymcpvydqmur:F1zxWuM9rKQ8CaQc@aws-1-us-east-1.pooler.supabase.com:5432/postgres'

async function setupStagingDatabase() {
  const client = new Client({
    connectionString: STAGING_DATABASE_URL,
    ssl: {
      rejectUnauthorized: false
    }
  })

  try {
    await client.connect()
    console.log('✓ Connected to staging database')

    // 1. Create audits table (base table)
    console.log('\n1. Creating audits table...')
    await client.query(`
      CREATE TABLE IF NOT EXISTS audits (
        audit_id VARCHAR(255) PRIMARY KEY,
        file_url TEXT,
        provider_info JSONB,
        patient_info JSONB,
        service_info JSONB,
        financials JSONB,
        line_items JSONB,
        errors JSONB,
        is_paid BOOLEAN DEFAULT FALSE,
        payment_intent_id VARCHAR(255),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_audits_created_at ON audits(created_at);
      CREATE INDEX IF NOT EXISTS idx_audits_is_paid ON audits(is_paid);
    `)
    console.log('✓ Audits table created')

    // 2. Add charity care columns
    console.log('\n2. Adding charity care columns...')
    await client.query(`
      ALTER TABLE audits
      ADD COLUMN IF NOT EXISTS charity_analysis JSONB,
      ADD COLUMN IF NOT EXISTS savings JSONB;

      COMMENT ON COLUMN audits.charity_analysis IS 'Charity care eligibility analysis including FPL data, IRS verification, and NPI lookup';
      COMMENT ON COLUMN audits.savings IS 'Breakdown of savings: billing errors, charity care, and total';
    `)
    console.log('✓ Charity care columns added')

    // 3. Create users table
    console.log('\n3. Creating users table...')
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        full_name VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `)
    console.log('✓ Users table created')

    // 4. Create subscriptions table
    console.log('\n4. Creating subscriptions table...')
    await client.query(`
      CREATE TABLE IF NOT EXISTS subscriptions (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        stripe_subscription_id VARCHAR(255) UNIQUE,
        stripe_customer_id VARCHAR(255),
        plan_type VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL,
        current_period_start TIMESTAMP,
        current_period_end TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `)
    console.log('✓ Subscriptions table created')

    // 5. Add user references to audits
    console.log('\n5. Adding user references to audits...')
    await client.query(`
      ALTER TABLE audits ADD COLUMN IF NOT EXISTS user_id INTEGER REFERENCES users(id) ON DELETE SET NULL;
      ALTER TABLE audits ADD COLUMN IF NOT EXISTS payment_type VARCHAR(50);
    `)
    console.log('✓ User references added')

    // 6. Create indexes
    console.log('\n6. Creating indexes...')
    await client.query(`
      CREATE INDEX IF NOT EXISTS idx_audits_user_id ON audits(user_id);
      CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON subscriptions(user_id);
      CREATE INDEX IF NOT EXISTS idx_subscriptions_stripe_customer ON subscriptions(stripe_customer_id);
    `)
    console.log('✓ Indexes created')

    // 7. Create update trigger function
    console.log('\n7. Creating update triggers...')
    await client.query(`
      CREATE OR REPLACE FUNCTION update_updated_at_column()
      RETURNS TRIGGER AS $$
      BEGIN
        NEW.updated_at = CURRENT_TIMESTAMP;
        RETURN NEW;
      END;
      $$ LANGUAGE plpgsql;

      DROP TRIGGER IF EXISTS update_users_updated_at ON users;
      CREATE TRIGGER update_users_updated_at
        BEFORE UPDATE ON users
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();

      DROP TRIGGER IF EXISTS update_subscriptions_updated_at ON subscriptions;
      CREATE TRIGGER update_subscriptions_updated_at
        BEFORE UPDATE ON subscriptions
        FOR EACH ROW
        EXECUTE FUNCTION update_updated_at_column();
    `)
    console.log('✓ Update triggers created')

    // 8. Add Google OAuth support
    console.log('\n8. Adding Google OAuth support...')
    await client.query(`
      ALTER TABLE users
      ADD COLUMN IF NOT EXISTS google_id VARCHAR(255) UNIQUE,
      ADD COLUMN IF NOT EXISTS google_email VARCHAR(255),
      ADD COLUMN IF NOT EXISTS google_picture TEXT,
      ADD COLUMN IF NOT EXISTS auth_provider VARCHAR(50) DEFAULT 'local';

      CREATE INDEX IF NOT EXISTS idx_users_google_id ON users(google_id);

      UPDATE users SET auth_provider = 'local' WHERE auth_provider IS NULL;
    `)
    console.log('✓ Google OAuth support added')

    // 9. Create intermediate_audits table
    console.log('\n9. Creating intermediate_audits table...')
    await client.query(`
      CREATE TABLE IF NOT EXISTS intermediate_audits (
        audit_id UUID PRIMARY KEY,
        data JSONB NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );

      CREATE INDEX IF NOT EXISTS idx_intermediate_audits_created_at ON intermediate_audits(created_at);

      COMMENT ON TABLE intermediate_audits IS 'Temporary storage for audit data before financial information is submitted';
    `)
    console.log('✓ Intermediate audits table created')

    console.log('\n✅ Staging database setup complete!')
    console.log('\nTables created:')
    console.log('  - audits')
    console.log('  - users')
    console.log('  - subscriptions')
    console.log('  - intermediate_audits')

  } catch (error) {
    console.error('❌ Error setting up staging database:', error)
    throw error
  } finally {
    await client.end()
  }
}

setupStagingDatabase()
  .then(() => {
    console.log('\n✓ Database setup script completed successfully')
    process.exit(0)
  })
  .catch(error => {
    console.error('\n❌ Database setup script failed:', error)
    process.exit(1)
  })
