import pg from 'pg'
import dotenv from 'dotenv'

dotenv.config()

const { Client } = pg

console.log('🔍 Testing database connection...\n')

// Parse the DATABASE_URL
const dbUrl = process.env.DATABASE_URL
console.log('Database URL:', dbUrl?.substring(0, 40) + '...')

// Check for special characters in password
const urlMatch = dbUrl?.match(/postgresql:\/\/([^:]+):([^@]+)@([^:]+):(\d+)\/(.+)/)
if (urlMatch) {
  const [, user, password, host, port, database] = urlMatch
  console.log('\n📋 Connection Details:')
  console.log('   User:', user)
  console.log('   Password:', password.substring(0, 3) + '***' + password.substring(password.length - 3))
  console.log('   Host:', host)
  console.log('   Port:', port)
  console.log('   Database:', database)

  // Check if password needs encoding
  const hasSpecialChars = /[&%#@!]/.test(password)
  if (hasSpecialChars) {
    console.log('\n⚠️  WARNING: Password contains special characters')
    console.log('   The password should be URL-encoded in your .env file')
    console.log('   Current: ' + password)
    console.log('   Encoded: ' + encodeURIComponent(password))
  }
}

console.log('\n🔌 Attempting connection...')

const client = new Client({
  connectionString: dbUrl,
  ssl: {
    rejectUnauthorized: false
  }
})

try {
  await client.connect()
  console.log('✅ Successfully connected to database!')

  // Test query
  const result = await client.query('SELECT version()')
  console.log('\n📊 PostgreSQL Version:')
  console.log('   ', result.rows[0].version.substring(0, 50) + '...')

  await client.end()
  console.log('\n✨ Database connection test passed!')
  process.exit(0)
} catch (error) {
  console.error('\n❌ Connection failed:', error.message)
  console.error('\n🔧 Troubleshooting steps:')
  console.error('   1. Go to https://supabase.com/dashboard')
  console.error('   2. Select your project')
  console.error('   3. Check if the project is active (not paused)')
  console.error('   4. Go to Settings > Database')
  console.error('   5. Copy the "Connection string" (URI format)')
  console.error('   6. Make sure to URL-encode special characters in the password')
  console.error('   7. Replace DATABASE_URL in your .env file')
  process.exit(1)
}
