import Anthropic from '@anthropic-ai/sdk'
import dotenv from 'dotenv'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)
dotenv.config({ path: join(__dirname, '.env') })

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

console.log('Testing Claude 3.5 Sonnet access...\n')

// Try the exact model names from Anthropic's documentation
const sonnetModels = [
  'claude-3-5-sonnet-20241022',  // Latest version
  'claude-3-5-sonnet-20240620',  // Previous version
]

for (const model of sonnetModels) {
  try {
    console.log(`Testing ${model}...`)
    const message = await anthropic.messages.create({
      model: model,
      max_tokens: 10,
      messages: [{ role: 'user', content: 'Hi' }],
    })
    console.log(`  ✅ SUCCESS! ${model} is available`)
    console.log(`     This model supports: Images + PDFs + Documents`)
    process.exit(0)
  } catch (error) {
    console.log(`  ❌ ${model}: ${error.message}`)
  }
}

console.log('\n⚠️  No Claude 3.5 Sonnet access detected.')
console.log('\n📝 Your API key currently only has access to Claude 3 Haiku.')
console.log('   Haiku supports: Images only (no PDFs)')
console.log('\n💡 To enable PDF support, you need to:')
console.log('   1. Go to https://console.anthropic.com/')
console.log('   2. Check your API key tier/plan')
console.log('   3. Upgrade or request access to Claude 3.5 Sonnet')
console.log('\n   Claude 3.5 Sonnet includes:')
console.log('   ✓ PDF document support')
console.log('   ✓ Better accuracy for medical bill analysis')
console.log('   ✓ Longer context window')
