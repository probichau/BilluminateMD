import dotenv from 'dotenv'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

// Get current directory for ES6 modules
const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// Load environment variables with explicit path
const result = dotenv.config({ path: join(__dirname, '.env') })

console.log('Dotenv result:', result.error || 'Success')
console.log('\n🔐 Environment variables check:')
console.log('  ANTHROPIC_API_KEY:', process.env.ANTHROPIC_API_KEY ? '✅ Set (length: ' + process.env.ANTHROPIC_API_KEY.length + ')' : '❌ Missing')
console.log('  DATABASE_URL:', process.env.DATABASE_URL ? '✅ Set' : '❌ Missing')
console.log('  AWS_ACCESS_KEY_ID:', process.env.AWS_ACCESS_KEY_ID ? '✅ Set' : '❌ Missing')
console.log('  STRIPE_SECRET_KEY:', process.env.STRIPE_SECRET_KEY ? '✅ Set' : '❌ Missing')

if (process.env.ANTHROPIC_API_KEY) {
  console.log('\n✅ Environment variables loaded successfully!')
  console.log('Your backend should now work correctly.')
} else {
  console.log('\n❌ Environment variables NOT loaded!')
  console.log('Please check your .env file.')
}
