#!/bin/bash
# Extract key variables from .env and set them in EB

source .env

eb setenv \
  NODE_ENV=production \
  ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
  DATABASE_URL="$DATABASE_URL" \
  AWS_ACCESS_KEY_ID="$AWS_ACCESS_KEY_ID" \
  AWS_SECRET_ACCESS_KEY="$AWS_SECRET_ACCESS_KEY" \
  AWS_REGION="${AWS_REGION:-us-east-1}" \
  AWS_S3_BUCKET="$AWS_S3_BUCKET" \
  STRIPE_SECRET_KEY="$STRIPE_SECRET_KEY" \
  STRIPE_WEBHOOK_SECRET="${STRIPE_WEBHOOK_SECRET:-placeholder}" \
  JWT_SECRET="${JWT_SECRET:-change-this-in-production}" \
  FRONTEND_URL="https://billuminatemd-prod.eba-5yuhzdit.us-east-1.elasticbeanstalk.com" \
  PORT=8080

