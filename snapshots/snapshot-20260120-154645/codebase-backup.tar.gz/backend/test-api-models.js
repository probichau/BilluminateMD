import Anthropic from '@anthropic-ai/sdk'
import dotenv from 'dotenv'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

// Get current directory for ES6 modules
const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// Load environment variables
dotenv.config({ path: join(__dirname, '.env') })

console.log('Testing Anthropic API connection...\n')

if (!process.env.ANTHROPIC_API_KEY) {
  console.error('❌ ANTHROPIC_API_KEY not found in environment variables')
  process.exit(1)
}

console.log('✅ API Key found:', process.env.ANTHROPIC_API_KEY.substring(0, 20) + '...')

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
})

// Test different models
const modelsToTest = [
  'claude-3-opus-20240229',
  'claude-3-sonnet-20240229',
  'claude-3-haiku-20240307',
  'claude-3-5-sonnet-20240620',
  'claude-3-5-sonnet-20241022',
]

console.log('\nTesting models...\n')

for (const model of modelsToTest) {
  try {
    console.log(`Testing ${model}...`)
    const message = await anthropic.messages.create({
      model: model,
      max_tokens: 10,
      messages: [
        {
          role: 'user',
          content: 'Say "test"',
        },
      ],
    })

    console.log(`  ✅ ${model} works!`)
    console.log(`     Response: ${message.content[0].text}`)
  } catch (error) {
    console.log(`  ❌ ${model} failed: ${error.message}`)
  }
}

console.log('\n✅ Test complete!')
