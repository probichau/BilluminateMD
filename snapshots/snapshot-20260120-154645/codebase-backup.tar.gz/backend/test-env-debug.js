import dotenv from 'dotenv'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

// Get current directory for ES6 modules
const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

// Load environment variables with explicit path
const result = dotenv.config({ path: join(__dirname, '.env') })

console.log('Dotenv result:', result)
console.log('\nParsed keys:', result.parsed ? Object.keys(result.parsed) : 'none')
console.log('\nANTHROPIC_API_KEY in parsed?', result.parsed && 'ANTHROPIC_API_KEY' in result.parsed ? 'YES' : 'NO')
console.log('ANTHROPIC_API_KEY in process.env?', 'ANTHROPIC_API_KEY' in process.env ? 'YES' : 'NO')

if (result.parsed && 'ANTHROPIC_API_KEY' in result.parsed) {
  console.log('\nParsed value length:', result.parsed.ANTHROPIC_API_KEY.length)
  console.log('Parsed value starts with:', result.parsed.ANTHROPIC_API_KEY.substring(0, 20))
}
