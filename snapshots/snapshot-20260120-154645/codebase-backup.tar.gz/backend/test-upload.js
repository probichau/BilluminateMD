import dotenv from 'dotenv'
import fs from 'fs'
import FormData from 'form-data'
import fetch from 'node-fetch'

dotenv.config()

console.log('🧪 Testing bill upload endpoint...\n')

// Check environment variables
console.log('Environment check:')
console.log('  ANTHROPIC_API_KEY:', process.env.ANTHROPIC_API_KEY ? '✅ Set' : '❌ Missing')
console.log('  DATABASE_URL:', process.env.DATABASE_URL ? '✅ Set' : '❌ Missing')
console.log('  AWS_ACCESS_KEY_ID:', process.env.AWS_ACCESS_KEY_ID ? '✅ Set' : '❌ Missing')
console.log('')

// Test the health endpoint first
try {
  const healthResponse = await fetch('http://localhost:3001/health')
  const healthData = await healthResponse.json()
  console.log('✅ Backend health check:', healthData.message)
} catch (error) {
  console.error('❌ Backend not reachable:', error.message)
  console.log('\nMake sure the backend is running with: npm run dev')
  process.exit(1)
}

// Test if we can create a simple test upload
// (You would need a test bill image to test the actual upload)
console.log('\n📝 To test with a real bill:')
console.log('   1. Save a medical bill image/PDF')
console.log('   2. Try uploading through the frontend')
console.log('   3. Check backend terminal for error messages')
console.log('\n💡 Common issues:')
console.log('   - Anthropic API key invalid or expired')
console.log('   - File too large (>10MB)')
console.log('   - CORS issues (check browser console)')
console.log('   - Database connection lost')
