import { query } from './services/databaseService.js'

async function checkSubscription() {
  try {
    // Find user by email
    const userResult = await query(
      'SELECT id, email, full_name FROM users WHERE email = $1',
      ['bpr@robichau.com']
    )
    
    if (userResult.rows.length === 0) {
      console.log('❌ User not found')
      return
    }
    
    const user = userResult.rows[0]
    console.log('👤 User:', user)
    
    // Check subscription
    const subResult = await query(
      'SELECT * FROM subscriptions WHERE user_id = $1',
      [user.id]
    )
    
    console.log('\n📊 Subscriptions:', subResult.rows)
    
    // Check audits
    const auditResult = await query(
      'SELECT id, is_paid, payment_type, created_at FROM audits WHERE user_id = $1 ORDER BY created_at DESC LIMIT 5',
      [user.id]
    )
    
    console.log('\n📋 Recent audits:', auditResult.rows)
    
    process.exit(0)
  } catch (error) {
    console.error('Error:', error)
    process.exit(1)
  }
}

checkSubscription()
