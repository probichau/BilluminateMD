#!/bin/bash

# Staging Environment Variables Setup Script
# Replace the placeholder values below with your actual credentials

# IMPORTANT: Replace these values before running!
AWS_ACCESS_KEY_ID="YOUR_AWS_ACCESS_KEY_HERE"
AWS_SECRET_ACCESS_KEY="YOUR_AWS_SECRET_KEY_HERE"
ANTHROPIC_API_KEY="YOUR_ANTHROPIC_API_KEY_HERE"
STRIPE_SECRET_KEY="YOUR_STRIPE_TEST_KEY_HERE"  # Use sk_test_... for staging

# Fixed values (already configured)
AWS_BUCKET_NAME="billuminatemd-staging-uploads"
AWS_REGION="us-east-1"
DATABASE_URL="postgresql://postgres.bgliypuasymcpvydqmur:F1zxWuM9rKQ8CaQc@aws-1-us-east-1.pooler.supabase.com:5432/postgres"
NODE_ENV="staging"

echo "Setting environment variables for staging..."

# Make sure we're using the staging environment
eb use BilluminateMD-staging-env

# Set all environment variables
eb setenv \
  AWS_ACCESS_KEY_ID="$AWS_ACCESS_KEY_ID" \
  AWS_SECRET_ACCESS_KEY="$AWS_SECRET_ACCESS_KEY" \
  AWS_BUCKET_NAME="$AWS_BUCKET_NAME" \
  AWS_REGION="$AWS_REGION" \
  DATABASE_URL="$DATABASE_URL" \
  ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
  STRIPE_SECRET_KEY="$STRIPE_SECRET_KEY" \
  NODE_ENV="$NODE_ENV"

echo ""
echo "✅ Environment variables set!"
echo ""
echo "Note: STRIPE_WEBHOOK_SECRET will be added after webhook endpoint is created"
echo ""
echo "Verifying environment variables..."
eb printenv
