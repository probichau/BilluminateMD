import dotenv from 'dotenv'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __filename = fileURLToPath(import.meta.url)
const __dirname = dirname(__filename)

dotenv.config({ path: join(__dirname, '.env') })

console.log('ANTHROPIC_API_KEY exists:', !!process.env.ANTHROPIC_API_KEY)
console.log('ANTHROPIC_API_KEY length:', process.env.ANTHROPIC_API_KEY?.length)
console.log('ANTHROPIC_API_KEY value:', process.env.ANTHROPIC_API_KEY)
