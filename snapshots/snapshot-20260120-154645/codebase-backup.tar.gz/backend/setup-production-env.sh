#!/bin/bash
# Production Environment Variables Setup Script
# Fill in the values below, then run: bash setup-production-env.sh

# =============================================================================
# FILL IN YOUR VALUES BELOW
# =============================================================================

# AWS S3 Configuration (for file uploads)
# AWS Keys - Use your CLOUDFLARE R2 credentials (keep what you have)
# Line 10: Replace with your R2 Access Key
AWS_ACCESS_KEY_ID="309ba31aafd1a7b275ddfa38776b71f3"

# Line 11: Replace with your R2 Secret Key  
AWS_SECRET_ACCESS_KEY="e5eae8613119b3bf3dcda90238c6c1e62cb56b8c7058bfe74e551d3685273240"

# Lines 12-14: Already correct, leave as-is
AWS_BUCKET_NAME="billuminatemd-bills"
AWS_REGION="auto"
S3_ENDPOINT="https://5006c73e686abfd7056f05815abd8c2c.r2.cloudflarestorage.com"

# Line 17: Replace with your Anthropic key
ANTHROPIC_API_KEY="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"

# Line 20: Replace with your Stripe secret key
STRIPE_SECRET_KEY="sk_test_51Sr3L0Q7nTHP9xHXWouiifaQqj9wnkVEu9gW27SdO5oqLkdsJKHSdry3LczbDa6UyQE8JdmIlsfytEr2le8YLyQ300M7aJPxFU"

# Line 21: GET THIS FROM STRIPE (see below)
STRIPE_WEBHOOK_SECRET="whsec_ucqynOeVVcgsCOMcqDTaBviC5SWcCluA"

# Lines 24 & 27: Already correct, leave as-is
FRONTEND_URL="https://app.billuminate.com"
DATABASE_URL="postgresql://postgres.mjjvgyjhqhtlsdfwowjf:P0bSlIcpRzlU22JR@aws-0-us-west-2.pooler.supabase.com:6543/postgres"

# =============================================================================
# DO NOT EDIT BELOW THIS LINE
# =============================================================================

echo "Setting environment variables for billuminatemd-prod..."

cd "$(dirname "$0")"

# Use EB CLI to set environment variables
/Users/bernardpeterrobichau/Library/Python/3.13/bin/eb setenv \
  AWS_ACCESS_KEY_ID="$AWS_ACCESS_KEY_ID" \
  AWS_SECRET_ACCESS_KEY="$AWS_SECRET_ACCESS_KEY" \
  AWS_BUCKET_NAME="$AWS_BUCKET_NAME" \
  AWS_REGION="$AWS_REGION" \
  S3_ENDPOINT="$S3_ENDPOINT" \
  ANTHROPIC_API_KEY="$ANTHROPIC_API_KEY" \
  STRIPE_SECRET_KEY="$STRIPE_SECRET_KEY" \
  STRIPE_WEBHOOK_SECRET="$STRIPE_WEBHOOK_SECRET" \
  FRONTEND_URL="$FRONTEND_URL" \
  DATABASE_URL="$DATABASE_URL" \
  NODE_ENV="production"

if [ $? -eq 0 ]; then
  echo ""
  echo "✅ Environment variables set successfully!"
  echo ""
  echo "The environment will automatically restart with new variables."
  echo "This may take 2-3 minutes."
  echo ""
  echo "To verify, run:"
  echo "  cd backend"
  echo "  /Users/bernardpeterrobichau/Library/Python/3.13/bin/eb printenv"
else
  echo ""
  echo "❌ Failed to set environment variables"
  echo "Please check your values and try again"
  exit 1
fi
